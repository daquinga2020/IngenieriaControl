close all; 
clear all; 
clc;

figure
grid
hold

xmin=0;
xmax=25;
ymin=-1.5;
ymax=2;

axis([xmin xmax ymin ymax]); 
axis ('square');


